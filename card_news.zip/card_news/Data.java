package com.example.gim_yongjun.card_news;

/**
 * Created by gim-yongjun on 2017. 11. 2..
 */

public class Data {
    private String name;
    private int photo;

    public Data(String name, int photo) {
        this.name = name;
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public int getPhoto() {

        return photo;
    }
}

